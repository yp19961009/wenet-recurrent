## WeNet Web Demo

* How to install? `pip install -r requirements.txt`
* How to start? `python app.py`
* Doc for `wenetruntime`? please see [doc](../../runtime/binding/python/README.md) for more usage.


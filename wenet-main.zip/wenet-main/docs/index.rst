.. Wenet documentation master file, created by
   sphinx-quickstart on Thu Dec  3 11:43:53 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Wenet's documentation!
=================================


Wenet is an tansformer-based end-to-end ASR toolkit.

.. toctree::
   :maxdepth: 1
   :caption: Tutorial:

   ./python_binding.md
   ./papers.md
   ./tutorial_librispeech.md
   ./tutorial_aishell.md
   ./pretrained_models.md
   ./lm.md
   ./context.md
   ./runtime.md
   ./jit_in_wenet.md
   ./UIO.md


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
